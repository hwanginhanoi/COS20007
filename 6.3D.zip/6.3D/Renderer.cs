﻿namespace Custom_Project
{
    public class Game
    {
        private readonly Bitmap[] tileImages = new Bitmap[]
        {
            SplashKit.LoadBitmap("Assets/TileEmpty.png"),
            SplashKit.LoadBitmap("Assets/TileCyan.png"),
            SplashKit.LoadBitmap("Assets/TileBlue.png"),
            SplashKit.LoadBitmap("Assets/TileOrange.png"),
            SplashKit.LoadBitmap("Assets/TileYellow.png"),
            SplashKit.LoadBitmap("Assets/TileGreen.png"),
            SplashKit.LoadBitmap("Assets/TilePurple.png"),
            SplashKit.LoadBitmap("Assets/TileRed.png")
        };

        private readonly Bitmap[] blockImages = new Bitmap[]
        {
            SplashKit.LoadBitmap("Assets/Block-Empty.png"),
            SplashKit.LoadBitmap("Assets/Block-I.png"),
            SplashKit.LoadBitmap("Assets/Block-J.png"),
            SplashKit.LoadBitmap("Assets/Block-L.png"),
            SplashKit.LoadBitmap("Assets/Block-O.png"),
            SplashKit.LoadBitmap("Assets/Block-S.png"),
            SplashKit.LoadBitmap("Assets/Block-T.png"),
            SplashKit.LoadBitmap("Assets/Block-Z.png")
        };

        private readonly Bitmap[,] imageControls;
        private readonly int maxDelay = 1000;
        private readonly int minDelay = 75;
        private readonly int delayDecrease = 25;

        private GameState gameState = new GameState();

        private Bitmap[,] SetupGameCanvas(Grid grid)
        {
            Bitmap[,] imageControls = new Bitmap[grid.Rows, grid.Columns];
            int cellSize = 25;

            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0; c < grid.Columns; c++)
                {
                    Bitmap imageControl = new Bitmap(cellSize, cellSize);

                    imageControl.SetCellDetails((r - 2) * cellSize + 10, c * cellSize, cellSize, cellSize);
                    imageControls[r, c] = imageControl;
                }
            }

            return imageControls;
        }

        private void DrawGrid(Grid grid)
        {
            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0; c < grid.Columns; c++)
                {
                    int id = grid[r, c];
                    imageControls[r, c].DrawBitmap(tileImages[id]);
                }
            }
        }

        // Implement other Draw methods (DrawBlock, DrawNextBlock, etc.) similarly

        private void Draw()
        {
            SplashKit.ClearScreen();

            DrawGrid(gameState.GameGrid);
            // Call other Draw methods here (DrawBlock, DrawNextBlock, etc.)

            SplashKit.RefreshScreen();
        }

        private void Update()
        {
            int delay = Math.Max(minDelay, maxDelay - (gameState.Score * delayDecrease));
            SplashKit.Delay(delay);

            gameState.MoveBlockDown();
        }
    }
}
