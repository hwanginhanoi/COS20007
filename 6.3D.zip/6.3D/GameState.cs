﻿namespace Custom_Project
{
    public class GameState
    {
        public Grid GameGrid { get; }
        public Tetromino CurrentTetromino { get; }
        public int Score { get; set; }
        public int Level { get; set; }

        public GameState(int gridRows, int gridCols)
        {
            GameGrid = new Grid(gridRows, gridCols);
            CurrentTetromino = GenerateRandomTetromino();
            Score = 0;
            Level = 1;
        }

        public void Update()
        {
            // Perform game logic and update the game state
            // For example, handle tetromino movement, collision detection, line clearing, scoring, etc.
        }

        public void HandleInput(InputType input)
        {
            // Handle user input and update the game state accordingly
            // For example, move the tetromino based on input (left, right, rotate, etc.)
        }

        private Tetromino GenerateRandomTetromino()
        {
            // Generate and return a random tetromino
            // You can implement your own logic to randomly select a tetromino shape
        }

        // Other methods and properties specific to the game state can be added here
        // For example, methods to check game over condition, level progression, etc.
    }
}
