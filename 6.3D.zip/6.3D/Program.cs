﻿namespace Custom_Project
{
    public class Program
    {
        public static void Main()
        {
            // Set up the game window
            const int screenWidth = 800;
            const int screenHeight = 600;
            Window gameWindow = new Window("Tetris", screenWidth, screenHeight);

            while (!gameWindow.CloseRequested)
            {
      
              
                // Refresh the screen
                gameWindow.Refresh(120);
            }

            // Close the game window when the game loop ends
            gameWindow.Close();
        }
    }

}
