﻿namespace Custom_Project
{
    public class InputController
    {
        public static bool IsKeyTyped(KeyCode key) => SplashKit.KeyTyped(key);
    }
}
