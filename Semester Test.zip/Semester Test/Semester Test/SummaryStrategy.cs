﻿using System;

namespace Semester_Test
{
	public abstract class SummaryStrategy
	{
		public abstract void PrintSummary(List<int> numbers);
	}
}

