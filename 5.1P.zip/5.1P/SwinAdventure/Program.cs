﻿using SwinAdventure;

namespace SwinAdventure
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }

}